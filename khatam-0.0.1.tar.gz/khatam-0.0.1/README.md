khatam alrumuz
*seal of the codes*
Containing:

* VCF.py
  * init
    * vcf = VCF(filename)

* VCF Attributes:

  * sv_bed_position(row)
> returns chrom, start, end, svtype (0-base)
   
  * sv_confidence_interval(row)
> left start CI, right start CI, left end CI, right end CI (0-base) returns a 0-based postion of the start and end if CI positions are not present
