#!/usr/bin/env python
import os,sys
class Vcf():
	def __init__(self,filename):
		self.filename=filename
		self.fh = None # file handle for opening
		self.iid={} # [index]->sample id
		if not os.path.isfile(self.filename):
			sys.stderr.write('FATAL ERROR: {} does not exist\n'.format(self.filename))
			sys.stdout.write('FATAL ERROR: {} does not exist\n'.format(self.filename))
			sys.exit(1)
		if self.filename.endswith('.gz'):
			import gzip
			self.fh = gzip.open(self.filename,'rt',9)
		else: self.fh = open(self.filename,'r')
	def tokenize_info(self,row):
		return row[7].split(';')
	def sv_bed_position(self,row):
		""" 
		Input: list of the VCF entry split by tabs
		Returns: chromosome, start (0-base), end, sv type
		"""		
		chrom = row[0]
		start = str(int(row[1])-1)
		end,svtype=None,None
		info = self.tokenize_info(row)
		for entry in info:
			if entry.startswith('SVTYPE='): svtype=entry.replace('SVTYPE=','')
			if entry.startswith('END='): end=entry.replace('END=','')
		return chrom,start,end,svtype
	def sv_confidence_interval(self,row):
		"""
		Input: list of the VCF entry split by tabs
		Returns: 
			left start CI, right start CI, left end CI, right end CI (0-base)
			returns a 0-based postion of the start and end if CI positions are not present
		"""
		chrom,start,end,svtype = self.sv_bed_position(row)
		start_ci, end_ci = None,None
		s1,s2,e1,e2=None,None,None,None
		info = self.tokenize_info(row)
		for entry in info:
			if entry.startswith('CIPOS='): start_ci = entry.replace('CIPOS=','')
			if entry.startswith('CIEND='): end_ci = entry.replace('CIEND=','')
		if start_ci==None:
			s1,s2 = start,str(int(start)+1)
		else:
			c1,c2 = start_ci.split(',')
			s1 = str(int(start)-abs(int(c1)))
			s2 = str(int(start)+abs(int(c2))+1)
		if end_ci==None:
			e1,e2 = str(int(end)-1),end
		else:
			c1,c2 = end_ci.split(',')
			e1 = str(int(end)-abs(int(c1))-1)
			e2 = str(int(end)+abs(int(c2)))
		return s1,s2,e1,e2