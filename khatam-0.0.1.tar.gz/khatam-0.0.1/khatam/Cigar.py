#!/usr/bin/env python
import re
class Cigar():
	"""
	Input: CIGAR string 
	-------------------
	Attributes:
	  Cigar.left_clip : number of base pairs clipped, left of the alignment
	  Cigar.right_clip: number of base paired clipped, right of the alignment
	  Cigar.cig : list of the tokensized cigar string
	      each element of the list is a tuple object containing the CIGAR flag and the length in base pairs
	      example: 50S100M becomes [ (4,50),(0,100) ] 

    -------------------
    Functions:
      Cigar.right_position(left_position) : returns the right most position on the reference
	"""
	def __init__(self,cig=None):
		"""----------------------------------------------------------------"""
		"""Courtesy of Pysam:http://pysam.readthedocs.io/en/latest/api.html"""
		CODE2CIGAR= ['M','I','D','N','S','H','P','=','X','B']
		"""---------- 0   1   2   3   4   5   6   7   8   9 ---------------"""
		#if PY_MAJOR_VERSION >= 3: CIGAR2CODE = dict([y, x] for x, y in enumerate(CODE2CIGAR))
		#else: 
		CIGAR2CODE = dict([ord(y), x] for x, y in enumerate(CODE2CIGAR))
		CIGAR_REGEX = re.compile("(\d+)([MIDNSHP=XB])")
		parts = CIGAR_REGEX.findall(cig)
		self.cig=[(CIGAR2CODE[ord(y)], int(x)) for x,y in parts]
		left = 0
		right = 0
		leftFlg, leftLen = self.cig[0]
		rightFlg, rightLen = self.cig[-1]
		if leftFlg == 4 or leftFlg == 5: left = leftLen
		if rightFlg == 4 or rightFlg == 5: right = rightLen
		self.left_clip = left
		self.right_clip = right
	def right_position(self,left):
		for (flg,leng) in  self.cig:
			if flg == 0 or flg == 2 or flg==3 or flg==7 or flg==8: left=left+leng
		return left