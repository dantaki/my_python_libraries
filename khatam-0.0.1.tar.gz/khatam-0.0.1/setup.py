from setuptools import setup
import os
def read(fname):
    return open(os.path.join(os.path.dirname(__file__), fname)).read()
setup(
    name = "khatam",
    version = "0.0.1",
    author = "Danny Antaki",
    author_email = "dantaki@ucsd.edu",
    description = ("collection of genetic scripts"),
    license = "GPLv2",
    packages=['khatam'],
    long_description=read('README.md'),
    #install_requires=['numpy','pandas','scipy','tqdm','statsmodels'],
    classifiers=[
        'Development Status :: 3 - Alpha',
        'License :: OSI Approved :: GNU General Public License v2 (GPLv2)',
    ],
)
